package version

// Version is the current version of sword-tui
const Version = "v1.9.0"

// BuildNumber is set during compilation via -ldflags
var BuildNumber = "dev"
